# datastrict-setup

- sudo apt-get update
- sudo apt-get install -y libgbm-dev
- export CLOUDSDK_PYTHON=python2
- npm i pm2 -g
- pm2 start register.js
# auto-miner
