#!/bin/bash

npm start